export default {
  DARK: '#439A97',
  LIGHT: '#C58940',
  PRIMARY: '#E6DDC4',
  ERROR: '#ff0000',
};
